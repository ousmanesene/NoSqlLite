<?php
	class Sqlite3Facade
	{
		public function __construct()
		{
		
		}
	}
?>