<?php
	class CouchDBFactory
	{
		
	}
?>