<?php
	class OSSAgent
	{
		
	}
?>