<?php
	require_once('Agent.class.php');
	
	$agent = new Agent('Bill');
?>