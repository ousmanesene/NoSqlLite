<?php
	namespace HPCSA\Catalog;
	interface iCatalog
	{
		const URL_BASE = 'https://f1d001t02asw.itc.integra.fr:8444/csa/rest/';
		const URL_LIST_CATALOG = 'catalog?userIdentifier=<user_id>';
	}
?>