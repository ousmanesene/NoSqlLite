<?php
	namespace HPCSA\Organization;
	interface iOrganization
	{
		const URL_BASE = 'https://f1d001t02asw.itc.integra.fr:8444/csa/rest/';
		const URL_LIST_ORGANIZATION = 'organization?userIdentifier=<user_id>';
	}
?>